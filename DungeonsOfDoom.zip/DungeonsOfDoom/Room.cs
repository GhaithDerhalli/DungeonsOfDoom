﻿namespace DungeonsOfDoom
{
    class Room
    {
        public Monster Monster { get; set; }
        public Item Item { get; set; }

    }
}
